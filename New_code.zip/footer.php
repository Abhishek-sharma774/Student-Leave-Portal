<footer class="footer">
				<div class="container-fluid">
					<div class="row text-muted">
						<div class="col-6 text-start">
							<p class="mb-0">
								Developed By:  Kehkasha , Kankshi, Mayank.
							</p>
						</div>
						<div class="col-6 text-end">
							 Design & Develop  with <i class="fa fa-heart text-danger"></i>
						</div>
					</div>
				</div>
			</footer>
		</div>
	</div>

	<script src="Files/js/app.js"></script>

	

</body>


</html>